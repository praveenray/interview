package com.example.demo.service;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class StatsDB {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());
    private final ThreadPoolTaskExecutor executor;
    private Map<String, Row> table = new ConcurrentHashMap<>();
    private final Duration TIMEOUT;
    public StatsDB(ThreadPoolTaskExecutor executor,
                   int timeoutSecs) {
        this.executor = executor;
        this.TIMEOUT = Duration.ofSeconds(timeoutSecs);
    }

    public StatsDB submitted(String msgId) {
        this.table.put(msgId, new Row(msgId));
        return this;
    }

    public StatsDB success(String msgId) {
        Objects.requireNonNull(msgId);
        table.remove(msgId);
        return this;
    }

    public StatsDB failure(String msgId) {
        Objects.requireNonNull(msgId);
        var row = table.get(msgId);
        if (row != null) {
            table.put(msgId, row.withResponse(false));
        }
        return this;
    }

    public synchronized int failureCount() {
        long count = table.entrySet().stream().filter(e -> !e.getValue().success()).count();
        return (int) count;
    }

    public synchronized int failureCountWithRemoval() {
        int count = failureCount();
        table.entrySet().stream().filter(e -> !e.getValue().success()).forEach(e -> {
            table.remove(e.getKey());
        });
        return count;
    }

    private synchronized void markTimeouts() {
        table.entrySet().stream().filter(e -> {
            var responseTime = e.getValue().responseTime();
            var startTime = e.getValue().submitTime();
            if (responseTime == null) {
                var duration = Duration.between(startTime, Instant.now());
                return duration.compareTo(TIMEOUT) >= 0;
            }
            return false;
        }).forEach(e -> table.remove(e.getKey()));
    }

    @PostConstruct
    public void postInit() {
        LOG.info("Initializing StatsDB cleanup thread");
        executor.submit(() -> {
            try {
                while (true) {
                    LOG.debug("StatDB timeout detection");
                    markTimeouts();
                    Thread.sleep(1000);
                }
            } catch (Exception e) {
                LOG.warn("Failed in sleep. Ignoring.", e);
            }
        });
    }
}

record Row(String msgId, Instant submitTime, Instant responseTime, boolean success, boolean timeOut) {
    Row(String msgId) {
        this(msgId, Instant.now());
    }
    Row(String msgId, Instant submitTime) {
        this(msgId, submitTime, null, false, false);
    }
    public Row withResponse(boolean isSuccess) {
        return new Row(this.msgId, this.submitTime, Instant.now(), isSuccess, false);
    }

    public Row timeout() {
        return new Row(this.msgId, this.submitTime, Instant.now(), false, true);
    }
}
