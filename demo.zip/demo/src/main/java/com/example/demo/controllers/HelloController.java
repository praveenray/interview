package com.example.demo.controllers;

import com.example.demo.service.Services;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class HelloController {
    private final Services services;

    public HelloController(Services services) {
        this.services = services;
    }

    @GetMapping("/")
    public String index() {
        services.testPool();
        return "300: hello world ok\n";
    }

    @PostMapping("/unpause")
    public void unpause() {
        services.stopPause();
    }
}
