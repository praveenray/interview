package com.example.demo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class Ingestor {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());
    private final StatsDB statsDB;

    public Ingestor(StatsDB statsDB) {
        this.statsDB = statsDB;
    }

    public void processMessage(String msgId, String msg) {
        LOG.debug("Trying to ingest msg {}", msgId);
        int response = sendToFileProcessor(msgId, msg);
        switch (response) {
            case 200 -> statsDB.success(msgId);
            default -> statsDB.failure(msgId);
        }
    }

    private int sendToFileProcessor(String msgId, String msg) {
        
    }
}
