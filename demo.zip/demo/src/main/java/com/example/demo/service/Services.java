package com.example.demo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.IntStream;

@Service
public class Services {
    private final ThreadPoolTaskExecutor executor;
    private final AtomicBoolean pause;
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());

    private final Ingestor ingestor;
    private final int DELAY_MS = 100;
    private final StatsDB statsDB;
    public Services(ThreadPoolTaskExecutor executor, Ingestor ingestor, StatsDB statsDB) {
        this.executor = executor;
        this.ingestor = ingestor;
        this.statsDB = statsDB;
        this.pause = new AtomicBoolean(true);
    }

    public int computePollingWaitIfAny() {
        int failures = this.statsDB.failureCountWithRemoval();
        return failures*DELAY_MS;
    }

    public boolean submitNow(String msgId, String message) {
        Objects.requireNonNull(msgId);
        Objects.requireNonNull(message);
        try {
            executor.submit(() -> ingestor.processMessage(msgId, message));
            return true;
        } catch (TaskRejectedException e) {
            LOG.warn("Submission rejected. Thread Pool is full with (size,capacity)=({},{})", executor.getQueueSize(), executor.getQueueCapacity());
            return false;
        }
    }

    public void pollingLoop() {
        while (true) {
            if (executor.getQueueSize() == executor.getQueueCapacity()) {
                LOG.warn("Threadpool is full. Waiting...");
                handleWait(100);
            } else {
                handleWait(computePollingWaitIfAny());
                Queue<String> messages = poll();
                while(!messages.isEmpty()) {
                    var msgId = msg;
                    var msg = messages.poll();
                    if (!submitNow(msg, msg)) {
                        messages.add(msg);
                        break;
                    }
                    statsDB.submitted(msgId);
                }
                if (!messages.isEmpty()) {
                    // return messages to SQS
                    handleWait(100);
                }
            }
        }
    }

    public void stopPause() {
        this.pause.set(false);
        sleep(1);
        LOG.info("Queue Size: {}", executor.getQueueSize());
    }

    public void testPool() {
        LOG.debug("Testing Pool with DEBUG");
        pause.set(true);
        IntStream.range(1, 7).forEach((i) -> {
            try {
                executor.submit(() -> {
                    LOG.debug("Inside Thread ID {}", Thread.currentThread().getId());
                    while (pause.get()) {
                        sleep(1);
                    }
                    LOG.info("Unpausing {}", Thread.currentThread().getId());
                });
            } catch (TaskRejectedException e) {
                LOG.warn("Error {}", e.getClass().getName());
            }
        });
        LOG.info("Queue Size: {}", executor.getQueueSize());
    }

    public void sleep(int sec) {
        try {
            Thread.sleep(sec*1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
