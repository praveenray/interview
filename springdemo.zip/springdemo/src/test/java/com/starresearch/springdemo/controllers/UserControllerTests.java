package com.starresearch.springdemo.controllers;

import com.starresearch.springdemo.models.User;
import com.starresearch.springdemo.models.WebResponse;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UserControllerTests {
    @Value(value="${local.server.port}")
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;
    @Test
    void createUser() {
        String url = "http://localhost:"+port+"/users/create-random-user";
        Faker faker = new Faker();
        User user = new User();
        user.setInvestorName(faker.name().fullName());
        user.setJobTitle(301);
        user.setUserRole(401);
        user.setUserLocation(2);
        user.setInvestmentStrategy(102);
        user.setPrimaryContact("(406) 775-6460 x7182");
        user.setContactNo("(406) 775-6460 x7183");
        user.setEmail(faker.internet().emailAddress());
        user.setPassword(faker.internet().password());
        user.setStatus("onboarded");

        ResponseEntity<WebResponse> resp = restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(user), WebResponse.class);
        assertNotNull(resp);
        assertEquals(200, resp.getStatusCode().value());
        WebResponse webResponse = resp.getBody();
        assertNotNull(webResponse);
        assertTrue(webResponse.getId() > 0);
        System.out.println("ID = " + webResponse.getId());
    }

    @Test
    void noNameIsDetected() {
        String url = "http://localhost:"+port+"/users/create-random-user";
        User user = new User();
        ResponseEntity<WebResponse> resp = restTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(user), WebResponse.class);
        assertNotNull(resp);
        assertEquals(HttpStatus.BAD_REQUEST.value(), resp.getStatusCode().value());
    }
}
