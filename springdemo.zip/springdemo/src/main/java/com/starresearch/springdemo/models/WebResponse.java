package com.starresearch.springdemo.models;

import java.util.List;

public class WebResponse {
    int id;
    List<String> errors;

    public WebResponse(int id) {
        this.id = id;
    }

    public WebResponse(List<String> errors) {
        this.errors = errors;
    }

    public WebResponse() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }
}
