package com.starresearch.springdemo.controllers;

import com.starresearch.springdemo.models.User;
import com.starresearch.springdemo.models.WebResponse;
import net.datafaker.Faker;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.web.bind.annotation.*;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    private JdbcTemplate jdbc;

    public UserController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @PostMapping(
        value = "/create-random-user",
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<WebResponse> createRandomUser(@RequestBody User myUser) {
        if (myUser.getInvestorName() == null || myUser.getInvestorName().isBlank()) {
            return ResponseEntity.badRequest().body(new WebResponse(List.of("invalid name")));
        }
        Faker faker = new Faker();
        User user = new User();
        user.setInvestorName(faker.name().fullName());
        user.setJobTitle(301);
        user.setUserRole(401);
        user.setUserLocation(2);
        user.setInvestmentStrategy(102);
        user.setPrimaryContact("(406) 775-6460 x7182");
        user.setContactNo("(406) 775-6460 x7183");
        user.setEmail(faker.internet().emailAddress());
        user.setPassword(faker.internet().password());
        user.setStatus("onboarded");

        String insert = """
                insert into tpe.users(investor_name, job_title,  user_role, user_location, investment_strategy, primary_contact, contact_no, email, password, status)
                values 
                (?, ?,  ?, ?, ?, ?, ?, ?, ?, 'onboarded')
                returning id
                """;
        KeyHolder kh = new GeneratedKeyHolder();
        jdbc.update(conn -> {
            PreparedStatement stmt = conn.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            int i = 1;
            stmt.setString(i++, user.getInvestorName());
            stmt.setInt(i++, user.getJobTitle());
            stmt.setInt(i++, user.getUserRole());
            stmt.setInt(i++, user.getUserLocation());
            stmt.setInt(i++, user.getInvestmentStrategy());
            stmt.setString(i++, user.getPrimaryContact());
            stmt.setString(i++, user.getContactNo());
            stmt.setString(i++, user.getEmail());
            stmt.setString(i++, user.getPassword());
            return stmt;
        }, kh);
        List<String> names = jdbc.query("select investor_name, job_title from tpe.users limit 10", new Object[]{}, (rs, rowNum) -> rs.getString(1));

        return ResponseEntity.ok(new WebResponse((Integer) kh.getKey()));
    }
}
