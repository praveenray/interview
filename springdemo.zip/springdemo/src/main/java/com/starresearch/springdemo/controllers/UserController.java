package com.starresearch.springdemo.controllers;

import net.datafaker.Faker;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    private JdbcTemplate jdbc;
    public UserController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping(
        value="/create-random-user",
            produces = MediaType.TEXT_PLAIN_VALUE
    )
    public String createRandomUser() {
        Faker faker = new Faker();
        String insert = """
                insert into tpe.users(investor_name, job_title,  user_role, user_location, investment_strategy, primary_contact, contact_no, email, password, status)
                values 
                (?, 301,  401, 2, 102, '(406) 775-6460 x7182', '(406) 775-6460 x7182', ?, ?, 'onboarded')
                """;
        jdbc.update(insert, faker.name().fullName(), faker.internet().emailAddress(), faker.internet().password());

        List<String> names = jdbc.query("select investor_name, job_title from tpe.users limit 10", new Object[]{}, (rs, rowNum) ->  rs.getString(1));
        return String.join("\n", names);
    }

}
